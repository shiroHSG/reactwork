/*
const num1 = 10;
const num2 = 20;

export {num1, num2};
*/

const pList = [
    {
      id: 1,
      title : 'vest',
      content : 'Made in the Stree',
      price : 25000
    },
    {
      id: 2,
      title : 'blouse',
      content : 'Made in Korea',
      price : 20000
    },
    {
      id: 3,
      title : 'jacket',
      content : 'Made in France',
      price : 36000
    },
]

export default pList;